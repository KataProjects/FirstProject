export type * from './dataTable';
