export const SomeComponent = () => {
  return <div>Проверка алиаса</div>;
};