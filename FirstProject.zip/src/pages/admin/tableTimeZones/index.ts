export { TableTimeZonesPage } from './TableTimeZonesPage';
