export { PrivacyPolicy } from './PrivacyPolicy';
